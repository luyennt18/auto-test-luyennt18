package com.tcbs.examples;

import com.adaptavist.tm4j.junit.annotation.TestCase;
import com.tcbs.common.Configs;
import com.tcbs.questions.TheUser;
import com.tcbs.tasks.LogInTci3;
import net.serenitybdd.junit.runners.SerenityRunner;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.abilities.BrowseTheWeb;
import net.thucydides.core.annotations.Managed;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import static net.serenitybdd.screenplay.GivenWhenThen.*;
import static org.hamcrest.Matchers.equalTo;

@RunWith(SerenityRunner.class)
public class LoginTest {

  @Managed
  public static WebDriver hisBrowser;

  Actor normalUser = Actor.named("Normal user");

  @TestCase(name = "Verify user is able to log into TCI3")
  @Test
  public void verify_login() {
    givenThat(normalUser).can(BrowseTheWeb.with(hisBrowser));
    when(normalUser).attemptsTo(LogInTci3.withCredentials(Configs.normal_user_id, Configs.normal_user_pwd));
    then(normalUser).should(seeThat(TheUser.name(), equalTo(Configs.normal_user_name)));
  }
}
