package com.tcbs.tasks;

import com.tcbs.page_objects.LoginPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Open;
import net.thucydides.core.annotations.Step;

import static net.serenitybdd.screenplay.GivenWhenThen.when;

public class LogInTci3 implements Task {
  String usr;
  String pwd;

  public LogInTci3(String usr, String pwd) {
    this.usr = usr;
    this.pwd = pwd;
  }

  public static LogInTci3 withCredentials(String usr, String pwd) {
    return Tasks.instrumented(LogInTci3.class, usr, pwd);
  }

  @Override
  @Step("{0} logs into TCInvest 3")
  public <T extends Actor> void performAs(T actor) {

    when(actor).attemptsTo(
      Open.browserOn().the(LoginPage.class),
      Enter.theValue(usr).into(LoginPage.txtUsername),
      Enter.theValue(pwd).into(LoginPage.txtPassword),
      Click.on(LoginPage.btnLogin)
    );
  }
}
