package com.tcbs.common.db;

import com.tcbs.common.Configs;
import core.database.HibernateEdition;

public enum Database {
  TCBOND("tcbond"),
  TCINVEST("tcinvest"),
  CAS("cas"),
  FLEX("flex"),
  TIMELINE("timeline"),
  DWH("dwh"),
  TRADING("trading");

  private String value;

  Database(String value) {
    this.value = value;
  }

  public String getValue() {
    return value;
  }

  public HibernateEdition getConnection() {
    DbInfo dbInfo = Configs.getDbInfo(this.value);
    return dbInfo.getDbConnection();
  }
}
