package com.tcbs.common;

public enum Env {
  LOCAL("local"), TEST("test"), SIT("sit"), UAT("uat"),
  CORETEST("coretest");

  // {{start:logger}}
  private static final Env currentEnv;

  static {
    String env = "local";
    // This comes from -Denv={environment}
    if (ConfigBuilder.systemProperties().hasPath("env")) {
      env = ConfigBuilder.systemProperties().getString("env");
    }
    currentEnv = Env.valueOf(env.toUpperCase());
    System.out.println(String.format("Current Env: {%s}", currentEnv.getName()));
  }

  private final String name;

  Env(String name) {
    this.name = name;
  }

  public static Env get() {
    return currentEnv;
  }

  public String getName() {
    return name;
  }
}
