package com.tcbs.common;

public class CommonKey {
  public static final String LOGIN_INFO = "LOGIN_INFO";
  public static final String JWT_INFO = "JWT_INFO";

  public static final String WSO2_LOGIN_INFO = "WSO2_LOGIN_INFO";
}
