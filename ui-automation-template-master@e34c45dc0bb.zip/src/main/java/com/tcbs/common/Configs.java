package com.tcbs.common;

import com.tcbs.common.db.DbInfo;
import com.typesafe.config.Config;

public class Configs {

  private static Config conf;

  static {
    conf = ConfigBuilder.newBuilder()
      .withResource("automation.conf")
      .withResource("automation." + Env.get().getName() + ".conf")
      .build();
  }

  public Configs() {
  }

  public static DbInfo getDbInfo(String dbValue) {
    return new DbInfo(
      conf.getString(String.format("hibernate.%s.username", dbValue)),
      conf.getString(String.format("hibernate.%s.pass", dbValue)),
      conf.getString(String.format("hibernate.%s.url", dbValue)),
      conf.getString(String.format("hibernate.%s.config", dbValue)));
  }

  public static final String LOGIN_API = conf.getString("login.api");
  public static final String normal_user_name = conf.getString("users.tci.default.customer.name");
  public static final String normal_user_id = conf.getString("users.tci.default.customer.username");
  public static final String normal_user_pwd = conf.getString("users.tci.default.customer.password");

}
