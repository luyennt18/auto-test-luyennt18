package com.tcbs.questions;

import com.tcbs.page_objects.HomePage;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class TheUser {

  public static Question<String> name() {
    return actor ->
      Text.of(HomePage.lbl_username).viewedBy(actor).asString();
  }
}
