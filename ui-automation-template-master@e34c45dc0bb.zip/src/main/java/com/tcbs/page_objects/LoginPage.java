package com.tcbs.page_objects;

import core.ui.By;
import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.At;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("/guest/login")
@At(urls={"#HOST/guest/login"})
public class LoginPage extends PageObject {

  public static Target txtUsername = Target.the("username textbox").located(By.cssSelector(".username"));
  public static Target txtPassword = Target.the("password textbox").located(By.cssSelector(".password"));
  public static Target btnLogin = Target.the("login button").located(By.cssSelector(".mat-button-wrapper"));

}
