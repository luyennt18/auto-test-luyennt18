package com.tcbs.page_objects;

import net.serenitybdd.core.pages.PageObject;
import net.serenitybdd.screenplay.targets.Target;
import net.thucydides.core.annotations.At;
import net.thucydides.core.annotations.WhenPageOpens;

@At("#HOST/home")
public class HomePage extends PageObject {

  public static Target lbl_username = Target.the("username").locatedBy(".user-fullname");

  @WhenPageOpens
  public void waitUntilProfilePhotoApears() {
    element(lbl_username.getCssOrXPathSelector()).waitUntilVisible();
  }
}
